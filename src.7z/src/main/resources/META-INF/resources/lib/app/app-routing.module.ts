import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home.component';
//import { DetailsComponent } from './crud/details/details.component';
//import { CreateComponent } from './crud/create/create.component';
//import { UpdateComponent } from './crud/update/update.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent }, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true, enableTracing: false})],
  exports: [RouterModule],
  
})

export class AppRoutingModule { }

