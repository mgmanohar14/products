import { NgModule }      from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {APP_BASE_HREF} from '@angular/common';
//import { HttpClientModule } from "@angular/common/http";

//import { AppRoutingModule } from './app-routing.module';

import { AppComponent }  from './app.component';


//import { HomeComponent } from './home.component';
//import { CrudService } from './crud.service';

@NgModule({
	imports: [
		BrowserModule,
		FormsModule,
		//AppRoutingModule,
	],
	declarations: [
		AppComponent,
		
	],
	entryComponents: [AppComponent],
	bootstrap: [], // Do not bootstrap anything (see ngDoBootstrap() below)
	providers: [{provide: APP_BASE_HREF, useValue: '/'}]
})
export class AppModule {

	// Avoid bootstraping any component statically because we need to attach to
	// the portlet's DOM, which is different for each portlet instance and,
	// thus, cannot be determined until the page is rendered (during runtime).

	ngDoBootstrap() {}
}