import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CrudService } from './crud.service';

import { Product } from './product';

@Component({
  selector: 'app-home',
  template: `
  <h1>My Products</h1>
                <!-- <button type="button" [routerLink]="['/crud/create']">Create new product</button> -->
                <a href="#" routerLink="/crud/create/" class="btn btn-success">Create New Product</a>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>In Stock</th>                            
                            <th width="220px">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    </table>
  `,
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
	
  products: Product[] = [];


  constructor(
    public fb: FormBuilder,
		private router: Router,
    public crudService: CrudService
    ) { }


  ngOnInit() {
	  this.crudService.getAll().subscribe((data: Product[])=>{
      console.log(data);
      this.products = data;
    })
  }
}
