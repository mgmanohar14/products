import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from './product';
import { CrudService } from './crud.service';


@Component({
	selector: 'app-root',
	template: `
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a href="http://localhost:8089/o/products/product-list" class="nav-link active" routerLink="crud/create">Product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" routerLink="/home" routerLinkActive="active">ProductList</a>
        </li>
      </ul>
      
    </div>
</nav>
<h1>My Products</h1>
                <!-- <button type="button" [routerLink]="['/crud/create']">Create new product</button> -->
                <a href="#" routerLink="/crud/create/" class="btn btn-success">Create New Product</a>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Description</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>In Stock</th>                            
                            <th width="220px">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <h4>No Table Data Yet</h4>
                        
                    </tbody>
                    </table>
                    
	
	`,
})
export class AppComponent {
	
	title = 'angular-crud-example';
  
}