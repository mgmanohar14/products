package angular.crud.example.constants;

/**
 * @author manoharagm
 */
public class AngularCrudExamplePortletKeys {

	public static final String AngularCrudExample = "angularcrudexample";

}